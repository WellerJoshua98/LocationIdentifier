A Location tracker written in C# using Restful Api from:developer.here.com.
Require your own api key and Visual Studio code.